# ✅ GPT_MAESTRO_FICHIERS_INDEX_IMPORTABLE.md

## 📘 Fonction
Ce fichier est un **index exportable** qui :
- Recense **tous les fichiers actuellement présents** dans le dossier de base
- Précise leur type et leur **utilité dans la configuration de GPT**
- Permet de **préparer un import optimisé** dans GPT Builder (max 20 fichiers)

---

## 📌 Pourquoi l’utiliser ?
✔ Pour valider que tous les fichiers importants sont présents  
✔ Pour savoir quoi **fusionner, garder, ou supprimer**  
✔ Pour créer un **pack propre** à importer ou archiver

---

## 🔎 Catégories de fichiers présents

### 📁 Python
- 🐍 Script Python `02_Python_Logging_And_Exceptions.py`
- 🐍 Script Python `02b_Logging_And_Exceptions_Advanced.py`
- 🐍 Script Python `03_CSV_XLSX_Import_Export.py`
- 🐍 Script Python `03b_CSV_XLSX_Advanced.py`
- 🐍 Script Python `04_Scraping_BeautifulSoup.py`
- 🐍 Script Python `04b_Scraping_Advanced_Selenium.py`
- 🐍 Script Python `09_Test_Unitaires_Exemple.py`
- 🐍 Script Python `09b_Tests_Unittest_Pytest_Advanced.py`
- 🐍 Script Python `11_Streamlit_Dashboard_Exemple.py`

### 📁 WordPress PHP
- 🔌 Plugin WP `05_WordPress_Plugin_Template.php`
- 🔌 Plugin WP `05b_WordPress_Plugin_Avance.php`

### 📁 Documentation Markdown
- 🔹 `01_Python_PEP8_Guide.md`
- 🔹 `01b_PEP8_Conventions_Avance.md`
- 🔹 `06_WordPress_Theme_Structure.md`
- 🔹 `06b_Theme_WordPress_Structure_Avancee.md`
- 🔹 `07_WP_CLI_Cheat_Sheet.md`
- 🔹 `07b_WP_CLI_Cheat_Sheet_Avance.md`
- 🔹 `10_Checklist_Workflow.md`
- 🔹 `10b_Checklist_Workflow_Avance.md`
- 🔹 `12_WordPress_REST_API_Exemple.md`
- 🔹 `13_Theme_Enfant_WordPress.md`
- 🔹 `ARCHITECTURES_ALTERNATIVES.md`
- 🔹 `CONTEXT.md`
- 🔹 `EXEMPLES_ENTREE_SORTIE.md`
- 🔹 `GLOSSAIRE.md`
- 🔹 `GUIDE_VERSIONING.md`
- 🔹 `MODELE_STRUCTUREL_PROJET.md`
- 🔹 `PROCEDURE_SAUVEGARDE.md`
- 📄 Documentation `README_01_Python_Structure.md`
- 📄 Documentation `README_02_Tests_CSV.md`
- 📄 Documentation `README_03_Scraping_WordPress.md`
- 📄 Documentation `README_04_Checklists_Architecture.md`
- 📄 Documentation `README_05_Contexte_Rules.md`
- 📄 Documentation `README_ARCHITECTURE_EXEMPLES.md`
- 📄 Documentation `README_AUTO_INDEX.md`
- 📄 Documentation `README_CHECKLISTS_WORKFLOW.md`
- 📄 Documentation `README_CONTEXTE_ET_REGLES.md`
- 📄 Documentation `README_ESSENTIELS.md`
- 📄 Documentation `README_GLOBAL.md`
- 📄 Documentation `README_IMPORT.md`
- 📄 Documentation `README_IMPORT_FUSION.md`
- 📄 Documentation `README_KnowledgePack.md`
- 📄 Documentation `README_PYTHON_STRUCTURE.md`
- 📄 Documentation `README_WORDPRESS_OUTILS.md`
- 📄 Documentation `README_WORDPRESS_STRUCTURE.md`
- 🔹 `STARTUP.md`
- 🔹 `VERSIONS.md`

### 📁 Structures et Notes
- 🧱 Structure `08_Modular_Project_Structure.txt`
- 🧱 Structure `08b_Structure_Modulaire_Projets_Complexes.txt`

