# 🗂️ Auto-README – Index des fichiers de GPT Maestro

Ce fichier est généré automatiquement à partir du contenu du dossier de base.

## 📁 Python

- `02_Python_Logging_And_Exceptions.py`
- `02b_Logging_And_Exceptions_Advanced.py`
- `03_CSV_XLSX_Import_Export.py`
- `03b_CSV_XLSX_Advanced.py`
- `04_Scraping_BeautifulSoup.py`
- `04b_Scraping_Advanced_Selenium.py`
- `09_Test_Unitaires_Exemple.py`
- `09b_Tests_Unittest_Pytest_Advanced.py`
- `11_Streamlit_Dashboard_Exemple.py`

## 📁 WordPress PHP

- `05_WordPress_Plugin_Template.php`
- `05b_WordPress_Plugin_Avance.php`

## 📁 Documentation Markdown

- `01_Python_PEP8_Guide.md`
- `01b_PEP8_Conventions_Avance.md`
- `06_WordPress_Theme_Structure.md`
- `06b_Theme_WordPress_Structure_Avancee.md`
- `07_WP_CLI_Cheat_Sheet.md`
- `07b_WP_CLI_Cheat_Sheet_Avance.md`
- `10_Checklist_Workflow.md`
- `10b_Checklist_Workflow_Avance.md`
- `12_WordPress_REST_API_Exemple.md`
- `13_Theme_Enfant_WordPress.md`
- `ARCHITECTURES_ALTERNATIVES.md`
- `CONTEXT.md`
- `EXEMPLES_ENTREE_SORTIE.md`
- `GLOSSAIRE.md`
- `GUIDE_VERSIONING.md`
- `MODELE_STRUCTUREL_PROJET.md`
- `PROCEDURE_SAUVEGARDE.md`
- `README_01_Python_Structure.md`
- `README_02_Tests_CSV.md`
- `README_03_Scraping_WordPress.md`
- `README_04_Checklists_Architecture.md`
- `README_05_Contexte_Rules.md`
- `README_ARCHITECTURE_EXEMPLES.md`
- `README_CHECKLISTS_WORKFLOW.md`
- `README_CONTEXTE_ET_REGLES.md`
- `README_ESSENTIELS.md`
- `README_GLOBAL.md`
- `README_IMPORT.md`
- `README_IMPORT_FUSION.md`
- `README_KnowledgePack.md`
- `README_PYTHON_STRUCTURE.md`
- `README_WORDPRESS_OUTILS.md`
- `README_WORDPRESS_STRUCTURE.md`
- `STARTUP.md`
- `VERSIONS.md`

## 📁 Structures et Notes

- `08_Modular_Project_Structure.txt`
- `08b_Structure_Modulaire_Projets_Complexes.txt`

