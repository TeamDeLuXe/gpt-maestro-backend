# WP-CLI Avancé

- `wp post meta update` pour automatisation des champs
- `wp eval-file` pour exécuter un script PHP
- `wp db search 'texte'` pour recherche SQL
- `wp cron event list`
- `wp plugin update --all`