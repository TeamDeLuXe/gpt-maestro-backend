# WP-CLI Cheat Sheet

- `wp plugin install akismet --activate`
- `wp theme list`
- `wp user create nom email@example.com --role=editor`
- `wp export`
- `wp db export`