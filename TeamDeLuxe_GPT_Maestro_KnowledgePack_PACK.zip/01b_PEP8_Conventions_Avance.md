# Conventions Avancées Python

- Annotations de type
- Gestion des imports avec isort
- Utilisation de `black` pour formatter
- Convention des tests avec `pytest`
- Gestion mémoire et performance (profiling)

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"
```