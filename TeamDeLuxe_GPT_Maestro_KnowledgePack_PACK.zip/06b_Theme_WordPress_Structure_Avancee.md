# Structure Avancée Thème WordPress

- Template parts (`template-parts/`)
- Fichiers conditionnels (`category-news.php`, `single-product.php`)
- `functions.php` avec hooks personnalisés
- Chargement conditionnel des scripts/styles
- Utilisation de `get_template_part()` et `WP_Query` avancé