# Hiérarchie des templates WordPress

- `index.php`: fallback général
- `single.php`: articles
- `page.php`: pages
- `archive.php`: archives
- `functions.php`: logique PHP globale