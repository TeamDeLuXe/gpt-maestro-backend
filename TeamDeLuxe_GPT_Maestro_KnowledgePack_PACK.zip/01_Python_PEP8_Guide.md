# Guide PEP8 Python

- Indentation: 4 espaces
- Nommage: snake_case
- Longueur max ligne: 79 caractères
- Commentaires: Utiliser # pour commentaires simples
- Docstrings: Triple guillemets """

> Respecter les standards pour un code lisible et maintenable.