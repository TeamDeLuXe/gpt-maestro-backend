# Créer un thème enfant WordPress

1. Créer un dossier `mon-theme-enfant`
2. Ajouter `style.css` avec Template: parent-theme
3. Ajouter `functions.php` pour charger le style parent
4. Activer depuis l’admin WordPress