# Utilisation de la REST API WordPress

- Endpoint pour articles: `/wp-json/wp/v2/posts`
- Authentification avec JWT ou OAuth
- Créer un endpoint custom avec `register_rest_route()`
- Exemple de consommation depuis JS ou Python